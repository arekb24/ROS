#include "ros/ros.h"
#include "global_variables.h"
#include "std_msgs/Float64.h"
#include <stdlib.h>

 bool velocityCallback_done = false;
 bool steeringAngleCallback_done = false;

 float message_steering_vel=0;
 float message_steering_angle=0;
float value =0;
float processing (float vel, float angle)
{
  float result = vel + angle;
  return result;
}

void velocityCallback(const std_msgs::Float64::ConstPtr& msg_steering_vel)
{
 velocityCallback_done=true;
 message_steering_vel=msg_steering_vel->data;

  float result=processing (message_steering_vel,message_steering_angle);
  ROS_INFO("Result is : [%f]", result);
  velocityCallback_done=false;
  steeringAngleCallback_done=false;
	value = result;
}

void steeringAngleCallback(const std_msgs::Float64::ConstPtr& msg_steering_angle)
{
 steeringAngleCallback_done=true;
 message_steering_angle=msg_steering_angle->data;

  float result=processing (message_steering_vel,message_steering_angle);
  ROS_INFO("Result is : [%f]", result);
  velocityCallback_done=false;
  steeringAngleCallback_done=false;

}


int main(int argc, char **argv)
{

  ros::init(argc, argv, "car_kinematics");

  ros::NodeHandle n;

  ros::Publisher pub_gyro_angle = n.advertise<std_msgs::Float64>("gyro_angle", 1000);

  ros::Subscriber sub_steering_vel = n.subscribe("steering_velocity", 1000, velocityCallback);
  ros::Subscriber sub_steering_angle = n.subscribe("steering_angle", 1000, steeringAngleCallback);
  
  ros::Rate loop_rate(100);
  while (ros::ok())
  {

    std_msgs::Float64 msg_gyro_angle;

    msg_gyro_angle.data = value;

    pub_gyro_angle.publish(msg_gyro_angle);

	ROS_INFO("Result is : [%f]", value);

    ros::spinOnce();

    loop_rate.sleep();
  }


  return 0;
}
